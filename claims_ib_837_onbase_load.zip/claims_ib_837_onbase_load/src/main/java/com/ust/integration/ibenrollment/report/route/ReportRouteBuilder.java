
/*package com.ust.integration.ibenrollment.report.route;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

import com.ust.integration.ibenrollment.report.processor.CsvProcessor;

@Component
public class ReportRouteBuilder extends RouteBuilder {

	
	@SuppressWarnings("unchecked")
	@Override
	public void configure() throws Exception {

		String networkPath = "\\\\pacfile9\\groups\\Karthik";
		String localPath = "C:\\target\\";
		File networkFolder = new File(networkPath);
		if (networkFolder != null && networkFolder.isDirectory() && networkFolder.listFiles() != null) {
			List<String> fileNamesList = new ArrayList<String>();
			for (File networkfile : networkFolder.listFiles()) {
				fileNamesList.add(networkfile.getAbsolutePath());
				from("timer://OIE?repeatCount=1").
				toD("direct:processCsv",networkfile).process(new CsvProcessor(fileNamesList));;
			}
			
			
			// InputStream csvStream=new FileInputStream(networkfile);

		}

		*//**
		 * Writing Process CSV method
		 *//*

	//	from("direct:processCsv").to(localPath).process(new CsvProcessor());
	}
}


*/