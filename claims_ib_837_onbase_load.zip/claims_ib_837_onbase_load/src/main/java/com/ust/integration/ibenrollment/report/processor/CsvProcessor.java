package com.ust.integration.ibenrollment.report.processor;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.util.FileCopyUtils;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageEncoder;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.TIFFDecodeParam;

public class CsvProcessor implements Processor {
	private String fileName;

	public CsvProcessor(String fileName) {
		// TODO Auto-generated constructor stub
		this.fileName=fileName;
	}
	
	String networkPath = "\\\\pacfile9\\groups\\Karthik";

	public void process(Exchange exchange) throws Exception {

		FileInputStream fis = (FileInputStream) exchange.getIn().getBody();

		BufferedReader brMainCsv = new BufferedReader(new InputStreamReader(fis));

		String fileNametoRead[] = fileName.split("\\.");
		String localPath = "C:\\target\\";
		try {
		File netFile=new File(networkPath);
		for(File file:netFile.listFiles()) {
			File newFilePath=new File(localPath+file.getName());
			if(!newFilePath.exists()) {
			FileCopyUtils.copy(file,newFilePath);
			}
		}
		}
		catch(Exception e) {
			
		}
		

		System.out.println(fileNametoRead[1]);
		/*BufferedReader br = new BufferedReader(
				new InputStreamReader(new FileInputStream(localPath
						+ fileNametoRead[1] + ".lst")));*/
		BufferedReader br = null;
		BufferedWriter bw=null;

		try {
			brMainCsv = new BufferedReader(new InputStreamReader(new FileInputStream(new File(fileName))));
		
			 bw=new BufferedWriter(new FileWriter(new File(localPath+"output"+".csv")));
		//	bw.write(	brMainCsv.readLine());
			
			String mainline = brMainCsv.readLine();
			String line = null;
			while ((mainline=brMainCsv.readLine()) != null) {
				List<BufferedImage> bufferedImages = new ArrayList<BufferedImage>();
				br = new BufferedReader(
						new InputStreamReader(new FileInputStream(localPath
								+ fileNametoRead[1] + ".lst")));
				String[] mainmetadata = mainline.split("\\|");
				String mainaccNum = mainmetadata[0];
				// System.out.println(mainaccNum.length());

				mainaccNum = mainaccNum.substring(0, mainaccNum.length() - 2);
				// lst File

				BufferedImage img2 = null;
				while ((line = br.readLine()) != null) {
					String[] metadata = line.split("\\|");
					String accNum = metadata[1];
					accNum = accNum.substring(0, accNum.length() - 2);
					if (mainaccNum.equalsIgnoreCase(accNum)) {
						File newFile = new File(localPath + metadata[0]);
						System.out.println("is file existis " + newFile.exists());

						//File tempFile = new File(localPath + mainaccNum + ".png");
						File tempFile = new File(localPath + metadata[0] + ".png");
						
						

						SeekableStream s = new FileSeekableStream(newFile);
						TIFFDecodeParam param = null;
						com.sun.media.jai.codec.ImageDecoder dec = ImageCodec.createImageDecoder("tiff", s, param);
						RenderedImage op = dec.decodeAsRenderedImage(0);

						FileOutputStream fos = new FileOutputStream(tempFile);
						com.sun.media.jai.codec.JPEGEncodeParam jpgparam = new com.sun.media.jai.codec.JPEGEncodeParam();
						jpgparam.setQuality(100);
						ImageEncoder en = ImageCodec.createImageEncoder("jpeg", fos, jpgparam);
						en.encode(op);
						fos.flush();
						fos.close();

					

						
						//FileUtil.copyFile(newFile, tempFile);

					//	newFile.renameTo(tempFile);
						

						/*
						 * File dummyFile = new
						 * File("C:\\Users\\396566\\Downloads\\File-transfer-project-master\\" +
						 * "File-transfer-project-master\\FileTransfer\\FileTransfer\\src\\main\\resources\\"
						 * +"1.png"); // I have bear.jpg in my working directory FileInputStream
						 * dummyFileIs = new FileInputStream(dummyFile); BufferedImage image =
						 * ImageIO.read(dummyFileIs); //reading the image file
						 */

						img2 = ImageIO.read(tempFile);
						if (img2 != null) {
							bufferedImages.add(img2);
						}
					}
					//line = br.readLine();
				}
				//mainline = brMainCsv.readLine();
				if(fileNametoRead!=null && fileNametoRead[1]!=null) {
					BufferedImage[] arr = new BufferedImage[bufferedImages.size()]; 
					arr = bufferedImages.toArray(arr); 


					BufferedImage joinedImg = joinBufferedImage(arr);
					File fileCombined=new File("C:\\combined2\\"+ mainaccNum +".png");
					ImageIO.write(joinedImg, "png",fileCombined );
				
					bw.append(mainline+fileCombined.getAbsolutePath()+"\n");
					
					
					}
			}
			

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			br.close();
			fis.close();
			brMainCsv.close();
			bw.close();
		}

	}
	
	public BufferedImage joinBufferedImage(BufferedImage[] a) {

		int offset = 2;
		int minwidth = 0;
		int minheight = 0;

		int maxwidth = 0;
		int maxheight = 0;
		for (BufferedImage i : a)

		{
			if(maxwidth< i.getWidth()) {
			maxwidth =  i.getWidth();
			}
			maxheight = maxheight + i.getHeight();

		}
		maxwidth = maxwidth + offset;
		maxheight = maxheight + offset;
		// int height = Math.max(img1.getHeight(), img2.getHeight()) + offset;
		// int height =img1.getHeight()+img2.getHeight() + offset;
		BufferedImage newImage = new BufferedImage(maxwidth, maxheight, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = newImage.createGraphics();
		Color oldColor = g2.getColor();
		g2.setPaint(Color.BLACK);
		g2.fillRect(0, 0, maxwidth, maxheight);
		g2.setColor(oldColor);

		for (BufferedImage i : a)

		{
			g2.drawImage(i, null, 0, minheight );
			minwidth = i.getWidth();
			minheight = minheight+ i.getHeight();

		}

		// g2.drawImage(img1, null, 0, 0);
		// g2.drawImage(img2, null, img1.getWidth() + offset, 0);
		// g2.drawImage(img2, null, 0, img1.getHeight() + offset);
		g2.dispose();
		return newImage;
	}
}


