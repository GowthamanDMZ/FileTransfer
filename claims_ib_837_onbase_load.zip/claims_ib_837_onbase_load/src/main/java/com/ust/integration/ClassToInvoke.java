package com.ust.integration;

import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

import com.ust.integration.ibenrollment.report.processor.CsvProcessor;

public class ClassToInvoke {

	public static void main(String[] args) throws Exception {
		String networkPath = "\\\\pacfile9\\groups\\Karthik";
		String localPath = "C:\\target\\";
		String csvfilename="C:\\Users\\bkajjam\\Desktop\\Karthik\\CSV\\PHP_SHOVDIPFile_20190228_las.b104309.dat.xml.csv";
		CamelContext context = new DefaultCamelContext();
	//	final String fileName = "PHP_SHOVDIPFile_20190228_las.b104309.dat.xml.csv";
		try {
			/*
			 * context.addComponent("activemq",
			 * ActiveMQComponent.activeMQComponent("vm://localhost?broker.persistent=false")
			 * );
			 */

			context.addRoutes(new RouteBuilder() {
				@Override
				public void configure() throws Exception {
					
						//for (File networkfile : networkFolder.listFiles()) {
							from("direct:testCsv").to("file:"+localPath).process(new CsvProcessor(csvfilename));
				}

			});

			context.start();
			ProducerTemplate template = context.createProducerTemplate();
			//String csvfilename = "";
			InputStream orderxml = new FileInputStream(csvfilename);
			template.setDefaultEndpointUri("direct:testCsv");
			template.sendBody("direct:testCsv",orderxml);
		} finally {
			context.stop();
		}
	}
}
