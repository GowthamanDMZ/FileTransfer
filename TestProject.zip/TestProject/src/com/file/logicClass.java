package com.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class logicClass {
	
	public List<File> getCSVFiles(String path) {
			
			List<File> csvFileList = new ArrayList<File>();
			File file = new File(path);
	        File[] files = file.listFiles();
	        try {
		        for(File f: files){
		            System.out.println(f.getName());
		            csvFileList.add(f);
		        }
	        }catch(Exception e) {
	        	System.out.println("no files");
	        }
			
	        return csvFileList;
		}
	
	public void returnFolder(List<File> csvFileList) {
		
		if(!csvFileList.isEmpty()) {
			
			
			for(File f : csvFileList) {
				System.out.println("-------------");
				String csvPath = Constants.csvPath;
				String lstPath = Constants.lstPath;
				String[] folderName = f.getName().split("\\.");
				lstPath = lstPath + folderName[0] + ".lst";
				try {
					File file = new File(lstPath);
					File[] lstFiles = file.listFiles();
					List<String> accNameFromCSV = getAccFromCSV(csvPath+f.getName());
			        for(File imageFile: lstFiles){
			        	String[] imageFileName = imageFile.getName().split("\\.");
			        	System.out.println(imageFileName[0]);
			        	if(accNameFromCSV.contains(imageFileName[0])) {
			        		System.out.println("image present");
			        		File files = new File(Constants.destinationFolder + "\\" + folderName[0]);
			        		if (!files.exists()) {
			                    if (files.mkdirs()) {
			                        System.out.println("Multiple directories are created!");
			                        
			                    } else {
			                        System.out.println("Failed to create multiple directories!");
			                    }
			                }
			        		imageFile.renameTo(new File(Constants.destinationFolder + "\\" + folderName[0] + "\\" + imageFile.getName()));
			        		
			        	}else {
			        		System.out.println("not present");
			        	}
			            
			        }
		        }catch(Exception e) {
		        	System.out.println("no imageFile");
		        }
			}
		}
	}
	
	
	public List<String> getAccFromCSV(String path) {
		
		Path pathToFile = Paths.get(path);
		List<String> accList = new ArrayList<String>();
		try (BufferedReader br = Files.newBufferedReader(pathToFile,
                StandardCharsets.US_ASCII)) {
			
			String line = br.readLine();
			 while (line != null) {
				 String[] metadata = line.split(",");
				 String accNum = metadata[0];
				 accList.add(accNum);
				 line = br.readLine();
			 }
			
		}catch (IOException ioe) {
            ioe.printStackTrace();
        }
		
		return  accList;
		
	}

}
