package com.file;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Path pathToFile = Paths.get("D:/Gowtham/myWork/csvFolder/fileName1.CSV");
		try (BufferedReader br = Files.newBufferedReader(pathToFile,
                StandardCharsets.US_ASCII)) {
			
			String line = br.readLine();
			 while (line != null) {
				 String[] metadata = line.split(",");
				 String name = metadata[0];
				 String price = metadata[1];
				 System.out.println(name + "," + price);
				 line = br.readLine();
			 }
			
		}catch (IOException ioe) {
            ioe.printStackTrace();
        }
		
	}

}
