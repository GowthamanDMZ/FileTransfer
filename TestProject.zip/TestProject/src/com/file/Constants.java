package com.file;

public class Constants {

	public static String csvPath = "D:/Gowtham/myWork/csvFolder/";
	public static String lstPath = "D:/Gowtham/myWork/lstFolder/";
	public static String destinationFolder = "D:/Gowtham/myWork/target/";
}
